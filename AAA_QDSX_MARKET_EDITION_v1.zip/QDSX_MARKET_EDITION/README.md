QDSX Market Edition — Physics-Inspired Data Compression

This folder contains qdsx_engine.py, a single-file data compression tool
based on my QDS work.

Basic usage:

    python qdsx_engine.py

More detailed examples and docs will be added here later.
